#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <errno.h>

#include "SortedList.h"
#include "common.h"

int main(int argc, char* argv[]) {
	set_program_name(argv[0]);
	printf("Hello, world!\n");

	return 0;
}